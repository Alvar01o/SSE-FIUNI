## Falcon, a theme by ThemeWagon team.

---

Get the figma design file here:
[https://www.figma.com/file/sBAjIWQIpl7FkHyV1ZDWC4/Falcon-Distributed-(v3.5.0)](<https://www.figma.com/file/sBAjIWQIpl7FkHyV1ZDWC4/Falcon-Distributed-(v3.5.0)>)
